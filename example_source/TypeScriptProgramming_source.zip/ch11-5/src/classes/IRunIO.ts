export interface IRunIO {
  runIO<R>(...args: any[]): R
}