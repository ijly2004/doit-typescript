import { A } from './A'
let a: A = new A()
a.method() // value: 1
