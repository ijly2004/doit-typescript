import { B } from './B'
let b: B = new B(2)
b.method() // value: 2
