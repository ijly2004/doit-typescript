export interface IValidation<T> {
  isSuccess: boolean
  isFailure: boolean
}