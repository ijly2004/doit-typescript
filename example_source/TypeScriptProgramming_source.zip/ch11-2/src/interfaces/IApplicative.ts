import {IApply} from './IApply'

export interface IApplicative<T> extends IApply<T> {
  //static of(value: T): this
}