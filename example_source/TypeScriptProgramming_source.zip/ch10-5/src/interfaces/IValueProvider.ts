export interface IValueProvider<T> {
  value(): T
}