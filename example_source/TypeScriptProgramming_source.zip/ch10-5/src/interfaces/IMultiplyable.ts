export interface IMultiplyable<T> {
  multiply(value: T): this
}