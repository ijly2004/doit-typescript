export interface IAddable<T> {
  add(value: T): this
}