import {IValueProvider} from './IValueProvider'
import {IAddable} from './IAddable'
import {IMultiplyable} from './IMultiplyable'

export {IValueProvider, IAddable, IMultiplyable}