let array = new Array
array.push(1); array.push(2); array.push(3)
console.log(array) // [1, 2, 3]
