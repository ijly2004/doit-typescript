for (let name of ['Jack', 'Jane', 'Steve']) console.log(name) // Jack Jane  Steve
