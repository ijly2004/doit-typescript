export const join = (strArray: string[], delim: string = ''): string => strArray.join(delim)
