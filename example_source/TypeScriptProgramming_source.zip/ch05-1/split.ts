export const split = (str: string, delim: string = ''): string[] => str.split(delim)
