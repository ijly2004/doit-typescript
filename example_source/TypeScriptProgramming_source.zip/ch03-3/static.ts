class A {
  static initValue = 1
}

let initVal = A.initValue // 1
