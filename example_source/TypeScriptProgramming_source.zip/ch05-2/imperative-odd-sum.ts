let oddSum = 0
for (let val = 1; val <= 100; val += 2) oddSum += val
console.log(oddSum) // 2500
