let squareSum = 0
for (let val = 1; val <= 100; ++val) squareSum += val * val
console.log(squareSum) // 338350
