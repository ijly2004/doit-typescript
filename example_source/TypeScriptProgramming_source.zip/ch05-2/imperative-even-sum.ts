let evenSum = 0
for (let val = 0; val <= 100; val += 2) evenSum += val
console.log(evenSum) // 2550
