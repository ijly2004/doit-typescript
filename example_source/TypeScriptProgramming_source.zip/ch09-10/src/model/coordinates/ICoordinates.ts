export type ICoordinates = {
  latitude: number, 
  longitude: number
}