import {IPerson, makeIPerson} from './makeIPerson'
import {makeRandomIPerson} from './makeRandomIPerson'

export { IPerson, makeIPerson, makeRandomIPerson }