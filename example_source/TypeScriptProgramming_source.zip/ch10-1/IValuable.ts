export interface IValuable<T> {
  value: T
}
