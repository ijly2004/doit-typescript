import {add} from './second-order-func'
console.log(
  add(1)(2) // 3
)