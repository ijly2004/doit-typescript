import {Option} from './option/Option'

let s: Option = Option.Some(1)
let n: Option = Option.None