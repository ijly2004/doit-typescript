import { init } from './init'
init(() => console.log('custom initialization finished.'))
