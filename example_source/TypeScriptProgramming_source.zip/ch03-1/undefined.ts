let u: undefined = undefined
//u = 1
