let a: any = 0
a = 'hello'
a = true
a = {}
