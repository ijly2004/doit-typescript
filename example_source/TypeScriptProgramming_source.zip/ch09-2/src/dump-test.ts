import * as R from 'ramda'
import { dump } from './dump'

dump(R.range(1, 10)) // // [ 1, 2, 3, 4, 5, 6, 7, 8, 9  ]
