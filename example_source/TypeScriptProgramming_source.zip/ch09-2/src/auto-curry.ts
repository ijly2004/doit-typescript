import * as R from 'ramda'

console.log(
  R.add(1, 2), //3
  R.add(1)(2)  //3
)