let original = 1
let copied = original
copied += 2
console.log(original, copied) // 1 3
