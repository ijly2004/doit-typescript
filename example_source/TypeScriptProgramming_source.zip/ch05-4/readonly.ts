function forcePure(array: readonly number []) {
  //array.push(1)
}