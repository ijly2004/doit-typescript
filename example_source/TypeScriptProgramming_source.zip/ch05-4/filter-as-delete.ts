let mixed: any[] = [
  [1, 2], {key: 1}, {name:"Jack"}, [4,5,6]
]