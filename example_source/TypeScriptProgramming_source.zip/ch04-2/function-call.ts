let functionExpression = function(a, b) {
  return a + b
}
let value = functionExpression(1, 2) // 3
