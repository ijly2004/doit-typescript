let value1 = (function(a, b) {
  return a + b
})(1, 2) // 3
