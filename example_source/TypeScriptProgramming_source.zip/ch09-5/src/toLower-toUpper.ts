import * as R from 'ramda'

console.log(
  R.toUpper("Hello"), // HELLO
  R.toLower("HELLO")  // hello
)