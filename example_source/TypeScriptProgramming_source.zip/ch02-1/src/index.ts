import { testMakePerson } from './utils/makePerson'
testMakePerson()
