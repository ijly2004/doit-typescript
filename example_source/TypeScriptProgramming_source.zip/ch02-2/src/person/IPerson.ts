export default interface IPerson {
  name: string,
  age: number
}