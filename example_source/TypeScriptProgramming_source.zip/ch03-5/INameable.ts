export default interface INameable {
  name: string
}
