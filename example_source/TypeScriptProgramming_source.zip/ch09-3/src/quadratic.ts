import {f, exp, square} from './f-using-ramda'

export const quadratic = f(1, 2, 1)
export {exp, square}