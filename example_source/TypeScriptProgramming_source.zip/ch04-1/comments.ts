let printMe2: (string, number) => void = function(name: string, age: number): void {}
